# -*- coding: utf-8 -*-
"""
/***************************************************************************
 placeStruct
                                 A QGIS plugin
 place_Struct
                              -------------------
        begin                : 2018-08-20
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Bharath
        email                : Bharath
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from datetime import *
import socket
import sys
import os.path
from PyQt4 import QtGui
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from qgis.core import *
from qgis.gui import *
from qgis.utils import iface
from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication, QVariant
from PyQt4.QtGui import QAction, QIcon,QMessageBox
# Initialize Qt resources from file resources.py
import resources
# Import the code for the dialog
from qgis.core import QgsRectangle,QgsFeatureRequest,QgsGeometry,QgsPoint
from qgis.gui import QgsMapToolEmitPoint
# Import the code for the dialog
from place_Struct_dialog import placeStructDialog
import os.path


class placeStruct(QgsMapToolEmitPoint):
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgisInterface
        """
        object.__init__(self)
        # Save reference to the QGIS interface
        self.iface = iface
        canvas = iface.mapCanvas()
        QgsMapToolEmitPoint.__init__(self, canvas)
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'placeStruct_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)


        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&place_Struct')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'placeStruct')
        self.toolbar.setObjectName(u'placeStruct')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('placeStruct', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        # Create the dialog (after translation) and keep reference
        self.dlg = placeStructDialog()

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/placeStruct/structure.png'
        action = self.add_action(
            icon_path,
            text=self.tr(u'place_Struct'),
            callback=self.run,
            parent=self.iface.mainWindow())
        
        self.pointEmitter = QgsMapToolEmitPoint(iface.mapCanvas())
        QObject.connect( self.pointEmitter, SIGNAL("canvasClicked(const QgsPoint, Qt::MouseButton)"), self.display_point)
        self.iface.mapCanvas().setMapTool( self.pointEmitter )

#         myToolBar = self.iface.mainWindow().findChild( QMenu, '&Techwave FLUX Programme' )
#         # If the menu does not exist, create it!
#         if not myToolBar:
#             myToolBar = QMenu( '&Techwave FLUX Programme', self.iface.mainWindow().menuBar() )
#             myToolBar.setObjectName( '&Techwave FLUX Programme' )
#             actions = self.iface.mainWindow().menuBar().actions()
#             lastAction = actions[-1]
#             self.iface.mainWindow().menuBar().insertMenu( lastAction, myToolBar )

# ##        myToolBar.clear()
#         if "Design Tools" not in myToolBar.children():
#             subMenu1 = myToolBar.addMenu("Design Tools")
#             subMenu1.addAction(action)
#             subMenu1.addSeparator()
#             myToolBar.addSeparator()

#         if "Validation Tools" not in myToolBar.children():
#             subMenu2 = myToolBar.addMenu("Validation Tools")
#             myToolBar.addSeparator()

#         if "Other Tools" not in myToolBar.children():
#             subMenu3 = myToolBar.addMenu("Other Tools")


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&place_Struct'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def display_point(self, point, button): 

        Ids = []
        boundary_Id = 0
        struct_Id = 0
        s_Ids = []
        structIds = 0
        Layer_boundary = iface.activeLayer()
        canvas = iface.mapCanvas()
        clickTool = QgsMapToolEmitPoint(canvas)
        w = canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(point.x()-w, point.y()-w, point.x()+w, point.y()+w)

        rect = canvas.mapSettings().mapToLayerCoordinates(Layer_boundary, rect)
        Layer_boundary.select(rect, False)

        
        
        point = self.toMapCoordinates(canvas.mouseLastXY())
        coords = "Map Coordinates: {:.4f}, {:.4f}".format(point.x(), point.y())
        featbond = Layer_boundary.selectedFeatures()

        selected_Boundary = None
        
        for eachfeatbond in featbond:
            if eachfeatbond["type"] == 'ADA':
                selected_Boundary = eachfeatbond
                boundary_Id = selected_Boundary["id"]
##                print(eachfeatbond["id"])
                
##        print selected_Boundary
##        print boundary_Id

        Layerboundary = QgsMapLayerRegistry.instance().mapLayersByName( 'boundary' )[0]
        
        for layer1 in QgsMapLayerRegistry.instance().mapLayers().values():            
            if layer1.name() == 'structurepoint':
                lineLayer2 = QgsMapLayerRegistry.instance().mapLayersByName( 'structurepoint' )[0]
                iface.setActiveLayer(lineLayer2)
                break

        lineLayer2 = self.iface.activeLayer()

        ##########---------- Structure Id incrementing -------------########
        
        for s_feat in lineLayer2.getFeatures():
            structIds = s_feat["Id"]
            if structIds != NULL:
                if boundary_Id in structIds:
##                    if self.dlg.cb_StructType.currentText() in structIds:
                    if s_feat.geometry().intersects(selected_Boundary.geometry()):
                        s_Ids.append(structIds)

##        print(s_Ids)
        if s_Ids:
            for structId in s_Ids:
                
                if '-' in structId:
                    if boundary_Id in structId:
##                        print s_feat["Id"]
                        if self.dlg.cb_StructType.currentText() == "Pit/Manhole":
                            if 'PIT' in structId:
##                                print structId
                                s_fields = structId.split('-')
                                Ids.append(s_fields[-1])
                                
                            else:
                                
                                struct_Id = boundary_Id + "-" + "PIT" + "-" + str(101).zfill(3)

                        if self.dlg.cb_StructType.currentText() == "NEC":
                            if 'NEC' in structId:
    ##                            print structId
                                s_fields = structId.split('-')
                                Ids.append(s_fields[-1])
                                
                            else:
                                
                                struct_Id = boundary_Id + "-" + self.dlg.cb_StructType.currentText() + "-" + str(101).zfill(3)

                        if self.dlg.cb_StructType.currentText() == "PPT":
                            if 'PPT' in structId:
    ##                            print structId
                                s_fields = structId.split('-')
                                Ids.append(s_fields[-1])
                                
                            else:
                                
                                struct_Id = boundary_Id + "-" + self.dlg.cb_StructType.currentText() + "-" + str(101).zfill(3)

                        if self.dlg.cb_StructType.currentText() == "CCU":
                            if 'CCU' in structId:
    ##                            print structId
                                s_fields = structId.split('-')
                                Ids.append(s_fields[-1])
                                
                            else:
                                
                                struct_Id = boundary_Id + "-" + self.dlg.cb_StructType.currentText() + "-" + str(101).zfill(3)
    ##                            print struct_Id

                        if self.dlg.cb_StructType.currentText() == "CTB":
                            if 'CTB' in structId:
    ##                            print structId
                                s_fields = structId.split('-')
                                Ids.append(s_fields[-1])
                                
                            else:
                                
                                struct_Id = boundary_Id + "-" + self.dlg.cb_StructType.currentText() + "-" + str(101).zfill(3)

                        if self.dlg.cb_StructType.currentText() == "POL":
                            if 'POL' in structId:
    ##                            print structId
                                s_fields = structId.split('-')
                                Ids.append(s_fields[-1])
                                
                            else:
                                
                                struct_Id = boundary_Id + "-" + self.dlg.cb_StructType.currentText() + "-" + str(101).zfill(3)
                                
                        if self.dlg.cb_StructType.currentText() == "Power Pit":
                            if 'PPT' in structId:
    ##                            print structId
                                s_fields = structId.split('-')
                                Ids.append(s_fields[-1])
                                
                            else:
                                
                                struct_Id = boundary_Id + "-" + "PPT" + "-" + str(101).zfill(3)



            if Ids:
                
                max_Id = max(Ids)
##                print max_Id
                new_Id = int(max_Id) + 001
##                print new_Id
                if self.dlg.cb_StructType.currentText() == "Pit/Manhole":
                    struct_Id = boundary_Id + "-" + "PIT" + "-" + str(new_Id).zfill(3)

                elif self.dlg.cb_StructType.currentText() == "Power Pit":
                    struct_Id = boundary_Id + "-" + "PPT" + "-" + str(new_Id).zfill(3)

                else:
                    struct_Id = boundary_Id + "-" + self.dlg.cb_StructType.currentText() + "-" + str(new_Id).zfill(3)
    ##            print(struct_Id)

        else:
##            print("yes")
            if self.dlg.cb_StructType.currentText() == "Pit/Manhole":
                
                struct_Id = boundary_Id + "-" + "PIT" + "-" + str(101).zfill(3)

            if self.dlg.cb_StructType.currentText() == "NEC":
                
                struct_Id = boundary_Id + "-" + "NEC" + "-" + str(101).zfill(3)

            if self.dlg.cb_StructType.currentText() == "PPT":
                
                struct_Id = boundary_Id + "-" + "PPT" + "-" + str(101).zfill(3)

            if self.dlg.cb_StructType.currentText() == "CCU":
                
                struct_Id = boundary_Id + "-" + "CCU" + "-" + str(101).zfill(3)

            if self.dlg.cb_StructType.currentText() == "CTB":
                
                struct_Id = boundary_Id + "-" + "CTB" + "-" + str(101).zfill(3)

            if self.dlg.cb_StructType.currentText() == "POL":
                
                struct_Id = boundary_Id + "-" + "POL" + "-" + str(101).zfill(3)

            if self.dlg.cb_StructType.currentText() == "Power Pit":
                
                struct_Id = boundary_Id + "-" + "PPT" + "-" + str(101).zfill(3)
                

        tw_Field = 'Techwave'
        
        index1 = lineLayer2.fieldNameIndex(tw_Field)
        
        if index1 == -1:
            lineLayer2.dataProvider().addAttributes( [ QgsField("Techwave", QVariant.String) ] )            
                
        lineLayer2.updateFields()
                
        lineLayer2.startEditing()
        
        provider = lineLayer2.dataProvider()
        #provider.addAttributes([QgsField("STRUCT_TYPE", QVariant.String),QgsField("Hierarchy", QVariant.String),QgsField("Material", QVariant.String),
                                #QgsField("Size", QVariant.Int),QgsField("Id", QVariant.Int)])
        ## create a new feature for the layer "myLayer"
        ft = QgsFeature(lineLayer2.fields())
        
##        feats = [ feat for feat in lineLayer.getFeatures() ]
        geo_pt = QgsGeometry.fromPoint(QgsPoint(point.x(), point.y()))
        
        ## set the geometry defined from the point X and Y
        ft.setGeometry(QgsGeometry.fromPoint(QgsPoint(point)))
        #ft.setGeometry(QgsGeometry.fromPolyline(QgsPoint(point.x(), point.y(), QgsPoint(point.x(), point.y())))
        ## set the value 1 to the new field "ID"
        #ft.setAttributes([1])

        ####------ set attributes ----########
        
        ft.setAttribute('owner', 'NBN')
        ft.setAttribute('object_status', 'PLANNED')
        ft.setAttribute('Techwave', 'NEW')
        ft.setAttribute('asset_transfer', 'N')
        
        ft.setAttribute('structure_type', self.dlg.cb_StructType.currentText())
        ft.setAttribute('hierarchy', self.dlg.cb_Hierarchy.currentText())
        ft.setAttribute('material', self.dlg.cb_Material.currentText())
        ft.setAttribute('size',self.dlg.cb_Size.currentText())
        ft.setAttribute('id',struct_Id)
        ## finally insert the feature
        provider.addFeatures([ft])
        self.iface.actionIdentify().trigger()
        ## add layer to the registry and over the map canvas
        #QgsMapLayerRegistry.instance().addMapLayer(vl)
        # update the fields
        lineLayer2.updateFields()
        # update the extent of the layer
        lineLayer2.updateExtents()
        lineLayer2.commitChanges()
        lineLayer2.triggerRepaint()
        lineLayer2.reload()
        lineLayer2.dataProvider().reloadData()
        lineLayer2.dataProvider().forceReload()
        Layerboundary.removeSelection()
##        dlg = self.iface.mainWindow().findChild(QDialog, 'IdentifyResults')
##        dlg.show()
        self.iface.mapCanvas().refresh()

        
##        id = -1
##
##        for feat in feats:
##            if geo_pt.within(feat.geometry()):
##                id = feat.id()
##                break
##
##                if id != -1:
##                    print feats[id].attribute('name')
##                else:
##                    print "no feature selected"
                    

    def run(self):
        """Run method that performs all the real work"""
        # show the dialog
        self.dlg.show()
        canvas = iface.mapCanvas()        
        self.dlg.cb_StructType.clear()
        self.dlg.cb_StructType.addItems(["Choose","Pit/Manhole","NEC","PPT","CCU","CTB","POL","Power Pit"])

        self.dlg.cb_StructType.currentIndexChanged.connect(self.indexChanged)
        # Run the dialog event loop
        result = self.dlg.exec_()               
        # See if OK was pressed
        if result:
            # Do something useful here - delete the line containing pass and substitute with your code.

            ###-----  form validation -----------###
            expDate = date(2021, 05, 31)
            if date.today() <= expDate:
                domain_name = socket.getfqdn()
                if "IN.TECHWAVE.NET" in domain_name.upper() or "INTECHWAVE" in domain_name.upper():
                    if self.dlg.cb_StructType.currentText() == "Choose":
                        
                        QMessageBox.information(iface.mainWindow(), "alert", u"Invalid Inputs")
                        #self.iface.mapCanvas().refresh() 
                        self.dlg.show()
                        
                    else:
                        # a reference to our map canvas 
                        canvas = iface.mapCanvas() 
                        ####----- Activating Layer ----#######
                        for layer11 in QgsMapLayerRegistry.instance().mapLayers().values():            
                            if layer11.name() == 'boundary':
                                lineLayer = QgsMapLayerRegistry.instance().mapLayersByName( 'boundary' )[0]
                                iface.setActiveLayer(lineLayer)
                                break
        ##                lineLayer.startEditing()
            ##            for layer11 in QgsMapLayerRegistry.instance().mapLayers().values():            
            ##                if layer11.name() == 'route':
            ##                    lineLayers = QgsMapLayerRegistry.instance().mapLayersByName( 'route' )[0]
            ##                    iface.setActiveLayer(lineLayers)
            ##                    break
            ##            lineLayers.startEditing()
            ##            lineLayer = iface.activeLayer()
                        
            ##            self.pointEmitter = QgsMapToolEmitPoint(iface.mapCanvas())
            ##            QObject.connect( self.pointEmitter, SIGNAL("canvasClicked(const QgsPoint, Qt::MouseButton)"), self.display_point)
            ##            self.iface.mapCanvas().setMapTool( self.pointEmitter )

                else:
                    self.dlg.close()
                    QMessageBox.warning(iface.mainWindow(), "exception error", u"error at system/python/modules, something went wrong unable to proceed ")
            else:
                self.dlg.close()
                QMessageBox.warning(iface.mainWindow(), "error", u"Tool expired, contact Techwave ")
            

#######------ Dropdown Function -------------------
                
    def indexChanged(self, index):
        StructType = self.dlg.cb_StructType.currentText()
        
        if self.dlg.cb_StructType.currentText() == "Choose":
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Material.clear()
            self.dlg.cb_Size.clear()

        if StructType == "Pit/Manhole":
            
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Hierarchy.addItems(["Pit","Joint Use","Null Node","End Cap","Utility Node","Manhole-Footway","Joint Enclosure - EJ","Customer Pit","Joint Enclosure - Std",
                                            "Pair Gain System(RIM)","Repair Point","Pillar","Indoor Cable Terminal Unit","Pedestal","FDH Pit","MDU","Cabinet","Telstra"])

            self.dlg.cb_Material.clear()
            self.dlg.cb_Material.addItems(["P(Thermoplastic)","-","()","A","C","Conc (Precast Reinforced Concrete)","New Item","Elevated Joint","H(Hand Moulded)","J(Injection Moulded)",
                                           "JC(jointing Cellulose)","Null","On Site","PC(Precast)","Prefabricated","Standard","Timber","H(Hand Moulded - Vic)","SPH 13202","Electrical Plastic"])
            self.dlg.cb_Size.clear()
            self.dlg.cb_Size.addItems(["5","1","2","3","4","6","7","8","9","-","2E","A","()","B","C",
                                       "D","EJ","Std","null","1800","900"])

        if StructType == "NEC":
            
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Hierarchy.addItems(["Null Node","Pit","Joint Use","End Cap","Utility Node","Manhole-Footway","Joint Enclosure - EJ","Customer Pit","Joint Enclosure - Std",
                                            "Pair Gain System(RIM)","Repair Point","Pillar","Indoor Cable Terminal Unit","Pedestal","FDH Pit","MDU","Cabinet","Telstra"])

            self.dlg.cb_Material.clear()
            self.dlg.cb_Material.addItems(["-","()","A","C","Conc (Precast Reinforced Concrete)","New Item","Elevated Joint","H(Hand Moulded)","J(Injection Moulded)",
                                           "JC(jointing Cellulose)","Null","On Site","P(Thermoplastic)","PC(Precast)","Prefabricated","Standard","Timber","H(Hand Moulded - Vic)","SPH 13202","Electrical Plastic"])
            self.dlg.cb_Size.clear()
            self.dlg.cb_Size.addItems(["-","1","2","3","4","5","6","7","8","9","2E","A","()","B","C",
                                       "D","EJ","Std","null","1800","900"])

        if StructType == "PPT":
            
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Hierarchy.addItems(["Pit","Power Pit","Null Node","Joint Use","End Cap","Utility Node","Manhole-Footway","Joint Enclosure - EJ","Customer Pit","Joint Enclosure - Std",
                                            "Pair Gain System(RIM)","Repair Point","Pillar","Indoor Cable Terminal Unit","Pedestal","FDH Pit","MDU","Cabinet","Telstra"])

            self.dlg.cb_Material.clear()
            self.dlg.cb_Material.addItems(["Electrical Plastic","-","()","A","C","Conc (Precast Reinforced Concrete)","New Item","Elevated Joint","H(Hand Moulded)","J(Injection Moulded)",
                                           "JC(jointing Cellulose)","Null","On Site","P(Thermoplastic)","PC(Precast)","Prefabricated","Standard","Timber","H(Hand Moulded - Vic)","SPH 13202"])
            self.dlg.cb_Size.clear()
            self.dlg.cb_Size.addItems(["-","1","2","3","4","5","6","7","8","9","2E","A","()","B","C",
                                       "D","EJ","Std","null","1800","900"])

        if StructType == "CCU":
            
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Hierarchy.addItems(["Pillar","Null Node","Joint Use","Pit","End Cap","Utility Node","Manhole-Footway","Joint Enclosure - EJ","Customer Pit","Joint Enclosure - Std",
                                            "Pair Gain System(RIM)","Repair Point","Indoor Cable Terminal Unit","Pedestal","FDH Pit","MDU","Cabinet","Telstra"])

            self.dlg.cb_Material.clear()
            self.dlg.cb_Material.addItems(["-","()","A","C","Conc (Precast Reinforced Concrete)","New Item","Elevated Joint","H(Hand Moulded)","J(Injection Moulded)",
                                           "JC(jointing Cellulose)","Null","On Site","P(Thermoplastic)","PC(Precast)","Prefabricated","Standard","Timber","Electrical Plastic","H(Hand Moulded - Vic)","SPH 13202"])
            self.dlg.cb_Size.clear()
            self.dlg.cb_Size.addItems(["900","-","1","2","3","4","5","6","7","8","9","2E","A","()","B","C",
                                       "D","EJ","Std","null","1800"])

        if StructType == "POL":
            
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Hierarchy.addItems(["Joint Use","Null Node","Pit","End Cap","Utility Node","Manhole-Footway","Joint Enclosure - EJ","Customer Pit","Joint Enclosure - Std",
                                            "Pair Gain System(RIM)","Repair Point","Pillar","Indoor Cable Terminal Unit","Pedestal","FDH Pit","MDU","Cabinet","Telstra"])

            self.dlg.cb_Material.clear()
            self.dlg.cb_Material.addItems(["-","()","A","C","Conc (Precast Reinforced Concrete)","New Item","Elevated Joint","H(Hand Moulded)","J(Injection Moulded)",
                                           "JC(jointing Cellulose)","Null","On Site","P(Thermoplastic)","PC(Precast)","Prefabricated","Standard","Timber","Electrical Plastic","H(Hand Moulded - Vic)","SPH 13202"])
            self.dlg.cb_Size.clear()
            self.dlg.cb_Size.addItems(["-","1","2","3","4","5","6","7","8","9","2E","A","()","B","C",
                                       "D","EJ","Std","null","1800","900"])

        if StructType == "CTB":
            
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Hierarchy.addItems(["-","Joint Use","Null Node","Pit","End Cap","Utility Node","Manhole-Footway","Joint Enclosure - EJ","Customer Pit","Joint Enclosure - Std",
                                            "Pair Gain System(RIM)","Repair Point","Pillar","Indoor Cable Terminal Unit","Pedestal","FDH Pit","MDU","Cabinet","Telstra"])

            self.dlg.cb_Material.clear()
            self.dlg.cb_Material.addItems(["-","()","A","C","Conc (Precast Reinforced Concrete)","New Item","Elevated Joint","H(Hand Moulded)","J(Injection Moulded)",
                                           "JC(jointing Cellulose)","Null","On Site","P(Thermoplastic)","PC(Precast)","Prefabricated","Standard","Timber","Electrical Plastic","H(Hand Moulded - Vic)","SPH 13202"])
            self.dlg.cb_Size.clear()
            self.dlg.cb_Size.addItems(["-","1","2","3","4","5","6","7","8","9","2E","A","()","B","C",
                                       "D","EJ","Std","null","1800","900"])

        if StructType == "Power Pit":
            
            self.dlg.cb_Hierarchy.clear()
            self.dlg.cb_Hierarchy.addItems(["Pit","Power Pit","Null Node","Joint Use","End Cap","Utility Node","Manhole-Footway","Joint Enclosure - EJ","Customer Pit","Joint Enclosure - Std",
                                            "Pair Gain System(RIM)","Repair Point","Pillar","Indoor Cable Terminal Unit","Pedestal","FDH Pit","MDU","Cabinet","Telstra"])

            self.dlg.cb_Material.clear()
            self.dlg.cb_Material.addItems(["Electrical Plastic","-","()","A","C","Conc (Precast Reinforced Concrete)","New Item","Elevated Joint","H(Hand Moulded)","J(Injection Moulded)",
                                           "JC(jointing Cellulose)","Null","On Site","P(Thermoplastic)","PC(Precast)","Prefabricated","Standard","Timber","H(Hand Moulded - Vic)","SPH 13202"])
            self.dlg.cb_Size.clear()
            self.dlg.cb_Size.addItems(["-","1","2","3","4","5","6","7","8","9","2E","A","()","B","C",
                                       "D","EJ","Std","null","1800","900"])


            
